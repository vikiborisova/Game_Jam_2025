﻿namespace bubbleGames.Resources
{
    partial class bubbleMaze
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.timerLabel = new System.Windows.Forms.Label();
            this.wallsPanel = new System.Windows.Forms.Panel();
            this.goal = new System.Windows.Forms.PictureBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ballon = new System.Windows.Forms.PictureBox();
            this.wallsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.goal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ballon)).BeginInit();
            this.SuspendLayout();
            // 
            // timerLabel
            // 
            this.timerLabel.AutoSize = true;
            this.timerLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.timerLabel.Location = new System.Drawing.Point(585, 37);
            this.timerLabel.Name = "timerLabel";
            this.timerLabel.Size = new System.Drawing.Size(213, 28);
            this.timerLabel.TabIndex = 0;
            this.timerLabel.Text = "Оставащо време: 60";
            // 
            // wallsPanel
            // 
            this.wallsPanel.Controls.Add(this.goal);
            this.wallsPanel.Controls.Add(this.panel19);
            this.wallsPanel.Controls.Add(this.panel18);
            this.wallsPanel.Controls.Add(this.panel17);
            this.wallsPanel.Controls.Add(this.panel16);
            this.wallsPanel.Controls.Add(this.panel15);
            this.wallsPanel.Controls.Add(this.panel14);
            this.wallsPanel.Controls.Add(this.panel13);
            this.wallsPanel.Controls.Add(this.panel12);
            this.wallsPanel.Controls.Add(this.panel11);
            this.wallsPanel.Controls.Add(this.panel10);
            this.wallsPanel.Controls.Add(this.panel9);
            this.wallsPanel.Controls.Add(this.panel8);
            this.wallsPanel.Controls.Add(this.panel7);
            this.wallsPanel.Controls.Add(this.panel6);
            this.wallsPanel.Controls.Add(this.panel4);
            this.wallsPanel.Controls.Add(this.panel2);
            this.wallsPanel.Controls.Add(this.panel3);
            this.wallsPanel.Controls.Add(this.panel1);
            this.wallsPanel.Controls.Add(this.ballon);
            this.wallsPanel.Location = new System.Drawing.Point(288, 68);
            this.wallsPanel.Name = "wallsPanel";
            this.wallsPanel.Size = new System.Drawing.Size(781, 598);
            this.wallsPanel.TabIndex = 1;
            // 
            // goal
            // 
            this.goal.BackColor = System.Drawing.Color.Green;
            this.goal.Location = new System.Drawing.Point(14, 179);
            this.goal.Name = "goal";
            this.goal.Size = new System.Drawing.Size(60, 60);
            this.goal.TabIndex = 21;
            this.goal.TabStop = false;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Black;
            this.panel19.Location = new System.Drawing.Point(513, 484);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(25, 75);
            this.panel19.TabIndex = 19;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Black;
            this.panel18.Location = new System.Drawing.Point(214, 359);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(200, 25);
            this.panel18.TabIndex = 18;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Location = new System.Drawing.Point(414, 259);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(25, 200);
            this.panel17.TabIndex = 17;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Location = new System.Drawing.Point(139, 259);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(75, 25);
            this.panel16.TabIndex = 16;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Black;
            this.panel15.Location = new System.Drawing.Point(114, 259);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(25, 100);
            this.panel15.TabIndex = 15;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Black;
            this.panel14.Location = new System.Drawing.Point(214, 259);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(25, 100);
            this.panel14.TabIndex = 14;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Black;
            this.panel13.Location = new System.Drawing.Point(314, 161);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(25, 100);
            this.panel13.TabIndex = 13;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(139, 459);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(200, 25);
            this.panel12.TabIndex = 12;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(414, 459);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(200, 25);
            this.panel11.TabIndex = 11;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(614, 39);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(25, 300);
            this.panel10.TabIndex = 10;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(539, 314);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(75, 25);
            this.panel9.TabIndex = 9;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(514, 161);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(25, 178);
            this.panel8.TabIndex = 8;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(139, 136);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(400, 25);
            this.panel7.TabIndex = 7;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(14, 259);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(25, 300);
            this.panel6.TabIndex = 6;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(739, 39);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(25, 520);
            this.panel4.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(14, 556);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(750, 25);
            this.panel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(14, 39);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(600, 25);
            this.panel3.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(14, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(25, 100);
            this.panel1.TabIndex = 1;
            // 
            // ballon
            // 
            this.ballon.BackgroundImage = global::bubbleGames.Properties.Resources._2;
            this.ballon.Image = global::bubbleGames.Properties.Resources._2;
            this.ballon.Location = new System.Drawing.Point(658, 39);
            this.ballon.Name = "ballon";
            this.ballon.Size = new System.Drawing.Size(60, 60);
            this.ballon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ballon.TabIndex = 0;
            this.ballon.TabStop = false;
            // 
            // bubbleMaze
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1348, 721);
            this.Controls.Add(this.wallsPanel);
            this.Controls.Add(this.timerLabel);
            this.Name = "bubbleMaze";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bubble Maze";
            this.Load += new System.EventHandler(this.bubbleMaze_Load);
            this.wallsPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.goal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ballon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label timerLabel;
        private System.Windows.Forms.Panel wallsPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox ballon;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.PictureBox goal;
    }
}