﻿namespace bubbleGames
{
    partial class bubblesPlay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bblsSpells = new System.Windows.Forms.PictureBox();
            this.bblShoot = new System.Windows.Forms.PictureBox();
            this.bblSays = new System.Windows.Forms.PictureBox();
            this.bubbleMatch = new System.Windows.Forms.PictureBox();
            this.bblMaze = new System.Windows.Forms.PictureBox();
            this.blnPop = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.bblsSpells)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bblShoot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bblSays)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bubbleMatch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bblMaze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blnPop)).BeginInit();
            this.SuspendLayout();
            // 
            // bblsSpells
            // 
            this.bblsSpells.Image = global::bubbleGames.Properties.Resources.bubbleSpells;
            this.bblsSpells.Location = new System.Drawing.Point(985, 397);
            this.bblsSpells.Name = "bblsSpells";
            this.bblsSpells.Size = new System.Drawing.Size(300, 300);
            this.bblsSpells.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bblsSpells.TabIndex = 5;
            this.bblsSpells.TabStop = false;
            this.bblsSpells.Click += new System.EventHandler(this.bblsSpells_Click);
            // 
            // bblShoot
            // 
            this.bblShoot.Image = global::bubbleGames.Properties.Resources.bubbleShoot;
            this.bblShoot.Location = new System.Drawing.Point(531, 397);
            this.bblShoot.Name = "bblShoot";
            this.bblShoot.Size = new System.Drawing.Size(300, 300);
            this.bblShoot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bblShoot.TabIndex = 4;
            this.bblShoot.TabStop = false;
            this.bblShoot.Click += new System.EventHandler(this.bubbleShoot_Click);
            // 
            // bblSays
            // 
            this.bblSays.Image = global::bubbleGames.Properties.Resources.bubbleSays;
            this.bblSays.Location = new System.Drawing.Point(77, 397);
            this.bblSays.Name = "bblSays";
            this.bblSays.Size = new System.Drawing.Size(300, 300);
            this.bblSays.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bblSays.TabIndex = 3;
            this.bblSays.TabStop = false;
            this.bblSays.Click += new System.EventHandler(this.bubbleSays_Click);
            // 
            // bubbleMatch
            // 
            this.bubbleMatch.Image = global::bubbleGames.Properties.Resources.bubbleMatch;
            this.bubbleMatch.Location = new System.Drawing.Point(985, 43);
            this.bubbleMatch.Name = "bubbleMatch";
            this.bubbleMatch.Size = new System.Drawing.Size(300, 300);
            this.bubbleMatch.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bubbleMatch.TabIndex = 2;
            this.bubbleMatch.TabStop = false;
            this.bubbleMatch.Click += new System.EventHandler(this.bubbleMatch_Click);
            // 
            // bblMaze
            // 
            this.bblMaze.Image = global::bubbleGames.Properties.Resources.bubbleMaze1;
            this.bblMaze.Location = new System.Drawing.Point(531, 43);
            this.bblMaze.Name = "bblMaze";
            this.bblMaze.Size = new System.Drawing.Size(300, 300);
            this.bblMaze.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bblMaze.TabIndex = 1;
            this.bblMaze.TabStop = false;
            this.bblMaze.Click += new System.EventHandler(this.bubbleMaze_Click);
            // 
            // blnPop
            // 
            this.blnPop.Image = global::bubbleGames.Properties.Resources.bubblePop;
            this.blnPop.Location = new System.Drawing.Point(77, 43);
            this.blnPop.Name = "blnPop";
            this.blnPop.Size = new System.Drawing.Size(300, 300);
            this.blnPop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blnPop.TabIndex = 0;
            this.blnPop.TabStop = false;
            this.blnPop.Click += new System.EventHandler(this.balloonPop_Click);
            // 
            // bubblesPlay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1348, 721);
            this.Controls.Add(this.bblsSpells);
            this.Controls.Add(this.bblShoot);
            this.Controls.Add(this.bblSays);
            this.Controls.Add(this.bubbleMatch);
            this.Controls.Add(this.bblMaze);
            this.Controls.Add(this.blnPop);
            this.Name = "bubblesPlay";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bubbles Play";
            ((System.ComponentModel.ISupportInitialize)(this.bblsSpells)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bblShoot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bblSays)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bubbleMatch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bblMaze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blnPop)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox blnPop;
        private System.Windows.Forms.PictureBox bblMaze;
        private System.Windows.Forms.PictureBox bubbleMatch;
        private System.Windows.Forms.PictureBox bblSays;
        private System.Windows.Forms.PictureBox bblShoot;
        private System.Windows.Forms.PictureBox bblsSpells;
    }
}

