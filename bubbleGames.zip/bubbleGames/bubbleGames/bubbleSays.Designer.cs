﻿namespace bubbleGames
{
    partial class bubbleSays
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(bubbleSays));
            this.lvlLbl = new System.Windows.Forms.Label();
            this.basic6 = new System.Windows.Forms.PictureBox();
            this.basic5 = new System.Windows.Forms.PictureBox();
            this.basic3 = new System.Windows.Forms.PictureBox();
            this.basic2 = new System.Windows.Forms.PictureBox();
            this.basic1 = new System.Windows.Forms.PictureBox();
            this.PurpleBbl_Says = new System.Windows.Forms.PictureBox();
            this.BlueBbl_Says = new System.Windows.Forms.PictureBox();
            this.AquaBbl_Says = new System.Windows.Forms.PictureBox();
            this.GreenBbl_Says = new System.Windows.Forms.PictureBox();
            this.YellowBbl_Says = new System.Windows.Forms.PictureBox();
            this.RedBbl_Says = new System.Windows.Forms.PictureBox();
            this.basic4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.basic6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PurpleBbl_Says)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlueBbl_Says)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AquaBbl_Says)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenBbl_Says)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YellowBbl_Says)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RedBbl_Says)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic4)).BeginInit();
            this.SuspendLayout();
            // 
            // lvlLbl
            // 
            this.lvlLbl.AutoSize = true;
            this.lvlLbl.BackColor = System.Drawing.Color.Transparent;
            this.lvlLbl.Font = new System.Drawing.Font("MS Gothic", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlLbl.ForeColor = System.Drawing.Color.Indigo;
            this.lvlLbl.Location = new System.Drawing.Point(426, 329);
            this.lvlLbl.Name = "lvlLbl";
            this.lvlLbl.Size = new System.Drawing.Size(481, 80);
            this.lvlLbl.TabIndex = 32;
            this.lvlLbl.Text = "Ниво: 1";
            // 
            // basic6
            // 
            this.basic6.BackColor = System.Drawing.Color.Transparent;
            this.basic6.Image = ((System.Drawing.Image)(resources.GetObject("basic6.Image")));
            this.basic6.Location = new System.Drawing.Point(1022, 451);
            this.basic6.Name = "basic6";
            this.basic6.Size = new System.Drawing.Size(222, 222);
            this.basic6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basic6.TabIndex = 38;
            this.basic6.TabStop = false;
            this.basic6.Click += new System.EventHandler(this.basic6_Click);
            // 
            // basic5
            // 
            this.basic5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.basic5.Image = ((System.Drawing.Image)(resources.GetObject("basic5.Image")));
            this.basic5.Location = new System.Drawing.Point(561, 451);
            this.basic5.Name = "basic5";
            this.basic5.Size = new System.Drawing.Size(222, 222);
            this.basic5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basic5.TabIndex = 37;
            this.basic5.TabStop = false;
            this.basic5.Click += new System.EventHandler(this.basic5_Click);
            // 
            // basic3
            // 
            this.basic3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.basic3.Image = ((System.Drawing.Image)(resources.GetObject("basic3.Image")));
            this.basic3.Location = new System.Drawing.Point(1022, 48);
            this.basic3.Name = "basic3";
            this.basic3.Size = new System.Drawing.Size(222, 222);
            this.basic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basic3.TabIndex = 35;
            this.basic3.TabStop = false;
            this.basic3.Click += new System.EventHandler(this.basic3_Click);
            // 
            // basic2
            // 
            this.basic2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.basic2.Image = ((System.Drawing.Image)(resources.GetObject("basic2.Image")));
            this.basic2.Location = new System.Drawing.Point(561, 48);
            this.basic2.Name = "basic2";
            this.basic2.Size = new System.Drawing.Size(222, 222);
            this.basic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basic2.TabIndex = 34;
            this.basic2.TabStop = false;
            this.basic2.Click += new System.EventHandler(this.basic2_Click);
            // 
            // basic1
            // 
            this.basic1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.basic1.Image = ((System.Drawing.Image)(resources.GetObject("basic1.Image")));
            this.basic1.Location = new System.Drawing.Point(105, 48);
            this.basic1.Name = "basic1";
            this.basic1.Size = new System.Drawing.Size(222, 222);
            this.basic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basic1.TabIndex = 33;
            this.basic1.TabStop = false;
            this.basic1.Click += new System.EventHandler(this.basic1_Click);
            // 
            // PurpleBbl_Says
            // 
            this.PurpleBbl_Says.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(95)))), ((int)(((byte)(211)))));
            this.PurpleBbl_Says.Image = global::bubbleGames.Properties.Resources.PurpleBbl_Says;
            this.PurpleBbl_Says.Location = new System.Drawing.Point(1022, 451);
            this.PurpleBbl_Says.Name = "PurpleBbl_Says";
            this.PurpleBbl_Says.Size = new System.Drawing.Size(222, 222);
            this.PurpleBbl_Says.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PurpleBbl_Says.TabIndex = 31;
            this.PurpleBbl_Says.TabStop = false;
            // 
            // BlueBbl_Says
            // 
            this.BlueBbl_Says.BackColor = System.Drawing.Color.Transparent;
            this.BlueBbl_Says.Image = global::bubbleGames.Properties.Resources.BlueBbl_Says;
            this.BlueBbl_Says.Location = new System.Drawing.Point(561, 451);
            this.BlueBbl_Says.Name = "BlueBbl_Says";
            this.BlueBbl_Says.Size = new System.Drawing.Size(222, 222);
            this.BlueBbl_Says.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BlueBbl_Says.TabIndex = 30;
            this.BlueBbl_Says.TabStop = false;
            // 
            // AquaBbl_Says
            // 
            this.AquaBbl_Says.BackColor = System.Drawing.Color.Transparent;
            this.AquaBbl_Says.Image = global::bubbleGames.Properties.Resources.AquaBbl_Says;
            this.AquaBbl_Says.Location = new System.Drawing.Point(105, 451);
            this.AquaBbl_Says.Name = "AquaBbl_Says";
            this.AquaBbl_Says.Size = new System.Drawing.Size(222, 222);
            this.AquaBbl_Says.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AquaBbl_Says.TabIndex = 29;
            this.AquaBbl_Says.TabStop = false;
            // 
            // GreenBbl_Says
            // 
            this.GreenBbl_Says.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(160)))), ((int)(((byte)(44)))));
            this.GreenBbl_Says.Image = global::bubbleGames.Properties.Resources.GreenBbl_Says;
            this.GreenBbl_Says.Location = new System.Drawing.Point(1022, 48);
            this.GreenBbl_Says.Name = "GreenBbl_Says";
            this.GreenBbl_Says.Size = new System.Drawing.Size(222, 222);
            this.GreenBbl_Says.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GreenBbl_Says.TabIndex = 28;
            this.GreenBbl_Says.TabStop = false;
            // 
            // YellowBbl_Says
            // 
            this.YellowBbl_Says.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(212)))), ((int)(((byte)(42)))));
            this.YellowBbl_Says.Image = global::bubbleGames.Properties.Resources.YellowBbl_Says;
            this.YellowBbl_Says.Location = new System.Drawing.Point(561, 48);
            this.YellowBbl_Says.Name = "YellowBbl_Says";
            this.YellowBbl_Says.Size = new System.Drawing.Size(222, 222);
            this.YellowBbl_Says.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.YellowBbl_Says.TabIndex = 27;
            this.YellowBbl_Says.TabStop = false;
            // 
            // RedBbl_Says
            // 
            this.RedBbl_Says.BackColor = System.Drawing.Color.Red;
            this.RedBbl_Says.Image = global::bubbleGames.Properties.Resources.RedBbl_Says;
            this.RedBbl_Says.Location = new System.Drawing.Point(105, 48);
            this.RedBbl_Says.Name = "RedBbl_Says";
            this.RedBbl_Says.Size = new System.Drawing.Size(222, 222);
            this.RedBbl_Says.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.RedBbl_Says.TabIndex = 26;
            this.RedBbl_Says.TabStop = false;
            // 
            // basic4
            // 
            this.basic4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(153)))));
            this.basic4.Image = global::bubbleGames.Properties.Resources.BasicBbl_Says;
            this.basic4.Location = new System.Drawing.Point(105, 451);
            this.basic4.Name = "basic4";
            this.basic4.Size = new System.Drawing.Size(222, 222);
            this.basic4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.basic4.TabIndex = 36;
            this.basic4.TabStop = false;
            this.basic4.Click += new System.EventHandler(this.basic4_Click);
            // 
            // bubbleSays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1348, 721);
            this.Controls.Add(this.basic6);
            this.Controls.Add(this.basic5);
            this.Controls.Add(this.basic4);
            this.Controls.Add(this.basic3);
            this.Controls.Add(this.basic2);
            this.Controls.Add(this.basic1);
            this.Controls.Add(this.lvlLbl);
            this.Controls.Add(this.PurpleBbl_Says);
            this.Controls.Add(this.BlueBbl_Says);
            this.Controls.Add(this.AquaBbl_Says);
            this.Controls.Add(this.GreenBbl_Says);
            this.Controls.Add(this.YellowBbl_Says);
            this.Controls.Add(this.RedBbl_Says);
            this.Name = "bubbleSays";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bubble Says";
            this.Load += new System.EventHandler(this.bubbleSays_Load);
            ((System.ComponentModel.ISupportInitialize)(this.basic6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PurpleBbl_Says)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlueBbl_Says)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AquaBbl_Says)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GreenBbl_Says)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YellowBbl_Says)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RedBbl_Says)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basic4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox basic6;
        private System.Windows.Forms.PictureBox basic5;
        private System.Windows.Forms.PictureBox basic3;
        private System.Windows.Forms.PictureBox basic2;
        private System.Windows.Forms.PictureBox basic1;
        private System.Windows.Forms.Label lvlLbl;
        private System.Windows.Forms.PictureBox PurpleBbl_Says;
        private System.Windows.Forms.PictureBox BlueBbl_Says;
        private System.Windows.Forms.PictureBox AquaBbl_Says;
        private System.Windows.Forms.PictureBox GreenBbl_Says;
        private System.Windows.Forms.PictureBox YellowBbl_Says;
        private System.Windows.Forms.PictureBox RedBbl_Says;
        private System.Windows.Forms.PictureBox basic4;
    }
}