﻿using bubbleGames.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bubbleGames
{
    public partial class bubblesPlay : Form
    {
        public bubblesPlay()
        {
            InitializeComponent();
        }

        private void bubbleSays_Click(object sender, EventArgs e)
        {
            bubbleSays bblSs = new bubbleSays();
            bblSs.Show();
        }

        private void bblsSpells_Click(object sender, EventArgs e)
        {
            bubbleSpells bblSays = new bubbleSpells();
            bblSays.Show();
        }

        private void balloonPop_Click(object sender, EventArgs e)
        {
            balloonPop balloonPop = new balloonPop();
            balloonPop.Show();
        }

        private void bubbleMaze_Click(object sender, EventArgs e)
        {
            bubbleMaze bubbleMaze = new bubbleMaze();
            bubbleMaze.Show();
        }

        private void bubbleMatch_Click(object sender, EventArgs e)
        {
            bubbleMatch bblMatch = new bubbleMatch();
            bblMatch.Show();
        }

        private void bubbleShoot_Click(object sender, EventArgs e)
        {
            bubbleShoot bblShoot = new bubbleShoot();
            bblShoot.Show();
        }
    }
}
