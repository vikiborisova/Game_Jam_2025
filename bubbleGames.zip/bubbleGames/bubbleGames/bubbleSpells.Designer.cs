﻿namespace bubbleGames
{
    partial class bubbleSpells
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(bubbleSpells));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ltr5 = new System.Windows.Forms.TextBox();
            this.ltr4 = new System.Windows.Forms.TextBox();
            this.ltr3 = new System.Windows.Forms.TextBox();
            this.ltr2 = new System.Windows.Forms.TextBox();
            this.ltr1 = new System.Windows.Forms.TextBox();
            this.legR3 = new System.Windows.Forms.PictureBox();
            this.armR3 = new System.Windows.Forms.PictureBox();
            this.armL3 = new System.Windows.Forms.PictureBox();
            this.legL3 = new System.Windows.Forms.PictureBox();
            this.body3 = new System.Windows.Forms.PictureBox();
            this.head3 = new System.Windows.Forms.PictureBox();
            this.legR2 = new System.Windows.Forms.PictureBox();
            this.armR2 = new System.Windows.Forms.PictureBox();
            this.armL2 = new System.Windows.Forms.PictureBox();
            this.legL2 = new System.Windows.Forms.PictureBox();
            this.body2 = new System.Windows.Forms.PictureBox();
            this.head2 = new System.Windows.Forms.PictureBox();
            this.legR1 = new System.Windows.Forms.PictureBox();
            this.armR1 = new System.Windows.Forms.PictureBox();
            this.armL1 = new System.Windows.Forms.PictureBox();
            this.legL1 = new System.Windows.Forms.PictureBox();
            this.body1 = new System.Windows.Forms.PictureBox();
            this.head1 = new System.Windows.Forms.PictureBox();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.timeLtrs = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.legR3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armR3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armL3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.legL3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.body3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.head3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.legR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.legL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.body2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.head2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.legR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.legL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.body1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.head1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.IndianRed;
            this.panel1.Location = new System.Drawing.Point(102, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(9, 319);
            this.panel1.TabIndex = 111;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.IndianRed;
            this.panel2.Location = new System.Drawing.Point(102, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 9);
            this.panel2.TabIndex = 92;
            // 
            // ltr5
            // 
            this.ltr5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(211)))), ((int)(((byte)(235)))));
            this.ltr5.Font = new System.Drawing.Font("MS Gothic", 80F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltr5.Location = new System.Drawing.Point(1071, 148);
            this.ltr5.Multiline = true;
            this.ltr5.Name = "ltr5";
            this.ltr5.ReadOnly = true;
            this.ltr5.Size = new System.Drawing.Size(129, 138);
            this.ltr5.TabIndex = 61;
            // 
            // ltr4
            // 
            this.ltr4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(211)))), ((int)(((byte)(235)))));
            this.ltr4.Font = new System.Drawing.Font("MS Gothic", 80F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltr4.Location = new System.Drawing.Point(929, 148);
            this.ltr4.Multiline = true;
            this.ltr4.Name = "ltr4";
            this.ltr4.ReadOnly = true;
            this.ltr4.Size = new System.Drawing.Size(129, 138);
            this.ltr4.TabIndex = 60;
            // 
            // ltr3
            // 
            this.ltr3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(211)))), ((int)(((byte)(235)))));
            this.ltr3.Font = new System.Drawing.Font("MS Gothic", 80F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltr3.Location = new System.Drawing.Point(787, 148);
            this.ltr3.Multiline = true;
            this.ltr3.Name = "ltr3";
            this.ltr3.ReadOnly = true;
            this.ltr3.Size = new System.Drawing.Size(129, 138);
            this.ltr3.TabIndex = 59;
            // 
            // ltr2
            // 
            this.ltr2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(211)))), ((int)(((byte)(235)))));
            this.ltr2.Font = new System.Drawing.Font("MS Gothic", 80F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltr2.Location = new System.Drawing.Point(645, 148);
            this.ltr2.Multiline = true;
            this.ltr2.Name = "ltr2";
            this.ltr2.ReadOnly = true;
            this.ltr2.Size = new System.Drawing.Size(129, 138);
            this.ltr2.TabIndex = 58;
            // 
            // ltr1
            // 
            this.ltr1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(211)))), ((int)(((byte)(235)))));
            this.ltr1.Font = new System.Drawing.Font("MS Gothic", 80F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltr1.Location = new System.Drawing.Point(503, 148);
            this.ltr1.Multiline = true;
            this.ltr1.Name = "ltr1";
            this.ltr1.ReadOnly = true;
            this.ltr1.Size = new System.Drawing.Size(129, 138);
            this.ltr1.TabIndex = 57;
            // 
            // legR3
            // 
            this.legR3.Image = global::bubbleGames.Properties.Resources.deadLegR;
            this.legR3.Location = new System.Drawing.Point(262, 238);
            this.legR3.Name = "legR3";
            this.legR3.Size = new System.Drawing.Size(100, 100);
            this.legR3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.legR3.TabIndex = 110;
            this.legR3.TabStop = false;
            this.legR3.Visible = false;
            // 
            // armR3
            // 
            this.armR3.Image = global::bubbleGames.Properties.Resources.deadLegR;
            this.armR3.Location = new System.Drawing.Point(294, 138);
            this.armR3.Name = "armR3";
            this.armR3.Size = new System.Drawing.Size(100, 100);
            this.armR3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.armR3.TabIndex = 109;
            this.armR3.TabStop = false;
            this.armR3.Visible = false;
            // 
            // armL3
            // 
            this.armL3.Image = global::bubbleGames.Properties.Resources.deadLegL;
            this.armL3.Location = new System.Drawing.Point(94, 138);
            this.armL3.Name = "armL3";
            this.armL3.Size = new System.Drawing.Size(100, 100);
            this.armL3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.armL3.TabIndex = 108;
            this.armL3.TabStop = false;
            this.armL3.Visible = false;
            // 
            // legL3
            // 
            this.legL3.Image = global::bubbleGames.Properties.Resources.deadLegL;
            this.legL3.Location = new System.Drawing.Point(122, 238);
            this.legL3.Name = "legL3";
            this.legL3.Size = new System.Drawing.Size(100, 100);
            this.legL3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.legL3.TabIndex = 107;
            this.legL3.TabStop = false;
            this.legL3.Visible = false;
            // 
            // body3
            // 
            this.body3.Image = global::bubbleGames.Properties.Resources.deadBody;
            this.body3.Location = new System.Drawing.Point(194, 138);
            this.body3.Name = "body3";
            this.body3.Size = new System.Drawing.Size(100, 100);
            this.body3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.body3.TabIndex = 106;
            this.body3.TabStop = false;
            this.body3.Visible = false;
            // 
            // head3
            // 
            this.head3.Image = global::bubbleGames.Properties.Resources.deadHead;
            this.head3.Location = new System.Drawing.Point(194, 38);
            this.head3.Name = "head3";
            this.head3.Size = new System.Drawing.Size(100, 100);
            this.head3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.head3.TabIndex = 105;
            this.head3.TabStop = false;
            this.head3.Visible = false;
            // 
            // legR2
            // 
            this.legR2.Image = global::bubbleGames.Properties.Resources.selectedLegR;
            this.legR2.Location = new System.Drawing.Point(262, 237);
            this.legR2.Name = "legR2";
            this.legR2.Size = new System.Drawing.Size(100, 100);
            this.legR2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.legR2.TabIndex = 104;
            this.legR2.TabStop = false;
            this.legR2.Visible = false;
            // 
            // armR2
            // 
            this.armR2.Image = global::bubbleGames.Properties.Resources.selectedLegR;
            this.armR2.Location = new System.Drawing.Point(294, 137);
            this.armR2.Name = "armR2";
            this.armR2.Size = new System.Drawing.Size(100, 100);
            this.armR2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.armR2.TabIndex = 103;
            this.armR2.TabStop = false;
            this.armR2.Visible = false;
            // 
            // armL2
            // 
            this.armL2.Image = global::bubbleGames.Properties.Resources.selectedLegL;
            this.armL2.Location = new System.Drawing.Point(94, 137);
            this.armL2.Name = "armL2";
            this.armL2.Size = new System.Drawing.Size(100, 100);
            this.armL2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.armL2.TabIndex = 102;
            this.armL2.TabStop = false;
            this.armL2.Visible = false;
            // 
            // legL2
            // 
            this.legL2.Image = global::bubbleGames.Properties.Resources.selectedLegL;
            this.legL2.Location = new System.Drawing.Point(122, 237);
            this.legL2.Name = "legL2";
            this.legL2.Size = new System.Drawing.Size(100, 100);
            this.legL2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.legL2.TabIndex = 101;
            this.legL2.TabStop = false;
            this.legL2.Visible = false;
            // 
            // body2
            // 
            this.body2.Image = global::bubbleGames.Properties.Resources.selectedBody;
            this.body2.Location = new System.Drawing.Point(194, 137);
            this.body2.Name = "body2";
            this.body2.Size = new System.Drawing.Size(100, 100);
            this.body2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.body2.TabIndex = 100;
            this.body2.TabStop = false;
            this.body2.Visible = false;
            // 
            // head2
            // 
            this.head2.Image = global::bubbleGames.Properties.Resources.selectedHead;
            this.head2.Location = new System.Drawing.Point(194, 37);
            this.head2.Name = "head2";
            this.head2.Size = new System.Drawing.Size(100, 100);
            this.head2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.head2.TabIndex = 99;
            this.head2.TabStop = false;
            this.head2.Visible = false;
            // 
            // legR1
            // 
            this.legR1.Image = global::bubbleGames.Properties.Resources.unselectedLegR;
            this.legR1.Location = new System.Drawing.Point(262, 239);
            this.legR1.Name = "legR1";
            this.legR1.Size = new System.Drawing.Size(100, 100);
            this.legR1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.legR1.TabIndex = 98;
            this.legR1.TabStop = false;
            // 
            // armR1
            // 
            this.armR1.Image = global::bubbleGames.Properties.Resources.unselectedLegR;
            this.armR1.Location = new System.Drawing.Point(294, 139);
            this.armR1.Name = "armR1";
            this.armR1.Size = new System.Drawing.Size(100, 100);
            this.armR1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.armR1.TabIndex = 97;
            this.armR1.TabStop = false;
            // 
            // armL1
            // 
            this.armL1.Image = global::bubbleGames.Properties.Resources.unselectedLegL;
            this.armL1.Location = new System.Drawing.Point(94, 139);
            this.armL1.Name = "armL1";
            this.armL1.Size = new System.Drawing.Size(100, 100);
            this.armL1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.armL1.TabIndex = 96;
            this.armL1.TabStop = false;
            // 
            // legL1
            // 
            this.legL1.Image = global::bubbleGames.Properties.Resources.unselectedLegL;
            this.legL1.Location = new System.Drawing.Point(122, 239);
            this.legL1.Name = "legL1";
            this.legL1.Size = new System.Drawing.Size(100, 100);
            this.legL1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.legL1.TabIndex = 95;
            this.legL1.TabStop = false;
            // 
            // body1
            // 
            this.body1.Image = global::bubbleGames.Properties.Resources.unselectedBody;
            this.body1.Location = new System.Drawing.Point(194, 139);
            this.body1.Name = "body1";
            this.body1.Size = new System.Drawing.Size(100, 100);
            this.body1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.body1.TabIndex = 94;
            this.body1.TabStop = false;
            // 
            // head1
            // 
            this.head1.Image = global::bubbleGames.Properties.Resources.unselectedHead;
            this.head1.Location = new System.Drawing.Point(194, 39);
            this.head1.Name = "head1";
            this.head1.Size = new System.Drawing.Size(100, 100);
            this.head1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.head1.TabIndex = 93;
            this.head1.TabStop = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Transparent;
            this.button30.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button30.BackgroundImage")));
            this.button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button30.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(1173, 611);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(82, 82);
            this.button30.TabIndex = 91;
            this.button30.Text = " ";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Transparent;
            this.button29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button29.BackgroundImage")));
            this.button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button29.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(1077, 611);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(82, 82);
            this.button29.TabIndex = 90;
            this.button29.Text = " ";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Transparent;
            this.button28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button28.BackgroundImage")));
            this.button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button28.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(981, 611);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(82, 82);
            this.button28.TabIndex = 89;
            this.button28.Text = " ";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Transparent;
            this.button27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button27.BackgroundImage")));
            this.button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button27.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(885, 611);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(82, 82);
            this.button27.TabIndex = 88;
            this.button27.Text = " ";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Transparent;
            this.button26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button26.BackgroundImage")));
            this.button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button26.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(789, 611);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(82, 82);
            this.button26.TabIndex = 87;
            this.button26.Text = " ";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Transparent;
            this.button25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button25.BackgroundImage")));
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button25.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(693, 611);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(82, 82);
            this.button25.TabIndex = 86;
            this.button25.Text = " ";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Transparent;
            this.button24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button24.BackgroundImage")));
            this.button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button24.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(597, 611);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(82, 82);
            this.button24.TabIndex = 85;
            this.button24.Text = " ";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Transparent;
            this.button23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button23.BackgroundImage")));
            this.button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button23.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(501, 611);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(82, 82);
            this.button23.TabIndex = 84;
            this.button23.Text = " ";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Transparent;
            this.button22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button22.BackgroundImage")));
            this.button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button22.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(405, 611);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(82, 82);
            this.button22.TabIndex = 83;
            this.button22.Text = " ";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Transparent;
            this.button21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button21.BackgroundImage")));
            this.button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button21.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(309, 611);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(82, 82);
            this.button21.TabIndex = 82;
            this.button21.Text = " ";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Transparent;
            this.button20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button20.BackgroundImage")));
            this.button20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button20.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(214, 611);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(82, 82);
            this.button20.TabIndex = 81;
            this.button20.Text = " ";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Transparent;
            this.button19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button19.BackgroundImage")));
            this.button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button19.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(1031, 524);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(82, 82);
            this.button19.TabIndex = 80;
            this.button19.Text = " ";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Transparent;
            this.button18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button18.BackgroundImage")));
            this.button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button18.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(935, 524);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(82, 82);
            this.button18.TabIndex = 79;
            this.button18.Text = " ";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Transparent;
            this.button17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button17.BackgroundImage")));
            this.button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button17.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(839, 524);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(82, 82);
            this.button17.TabIndex = 78;
            this.button17.Text = " ";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Transparent;
            this.button16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button16.BackgroundImage")));
            this.button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button16.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(743, 524);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(82, 82);
            this.button16.TabIndex = 77;
            this.button16.Text = " ";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Transparent;
            this.button15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button15.BackgroundImage")));
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button15.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(647, 524);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(82, 82);
            this.button15.TabIndex = 76;
            this.button15.Text = " ";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Transparent;
            this.button14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button14.BackgroundImage")));
            this.button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button14.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(551, 524);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(82, 82);
            this.button14.TabIndex = 75;
            this.button14.Text = " ";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Transparent;
            this.button13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button13.BackgroundImage")));
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button13.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(455, 524);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(82, 82);
            this.button13.TabIndex = 74;
            this.button13.Text = " ";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Transparent;
            this.button12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button12.BackgroundImage")));
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button12.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(359, 524);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(82, 82);
            this.button12.TabIndex = 73;
            this.button12.Text = " ";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Transparent;
            this.button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button11.BackgroundImage")));
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button11.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(1173, 436);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(82, 82);
            this.button11.TabIndex = 72;
            this.button11.Text = " ";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Transparent;
            this.button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button10.BackgroundImage")));
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button10.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(1077, 436);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(82, 82);
            this.button10.TabIndex = 71;
            this.button10.Text = " ";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Transparent;
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(981, 436);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 82);
            this.button9.TabIndex = 70;
            this.button9.Text = " ";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(885, 436);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(82, 82);
            this.button8.TabIndex = 69;
            this.button8.Text = " ";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(789, 436);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(82, 82);
            this.button7.TabIndex = 68;
            this.button7.Text = " ";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(693, 436);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(82, 82);
            this.button6.TabIndex = 67;
            this.button6.Text = " ";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(597, 436);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(82, 82);
            this.button5.TabIndex = 66;
            this.button5.Text = " ";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(501, 436);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 82);
            this.button4.TabIndex = 65;
            this.button4.Text = " ";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(405, 436);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(82, 82);
            this.button3.TabIndex = 64;
            this.button3.Text = " ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = global::bubbleGames.Properties.Resources.PurpleBbl_Says;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(309, 436);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 82);
            this.button2.TabIndex = 63;
            this.button2.Text = " ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::bubbleGames.Properties.Resources.PurpleBbl_Says;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("MS Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(214, 436);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 82);
            this.button1.TabIndex = 62;
            this.button1.Text = " ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timeLtrs
            // 
            this.timeLtrs.Interval = 10000;
            this.timeLtrs.Tick += new System.EventHandler(this.timeLtrs_Tick);
            // 
            // bubbleSpells
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1348, 721);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.legR3);
            this.Controls.Add(this.armR3);
            this.Controls.Add(this.armL3);
            this.Controls.Add(this.legL3);
            this.Controls.Add(this.body3);
            this.Controls.Add(this.head3);
            this.Controls.Add(this.legR2);
            this.Controls.Add(this.armR2);
            this.Controls.Add(this.armL2);
            this.Controls.Add(this.legL2);
            this.Controls.Add(this.body2);
            this.Controls.Add(this.head2);
            this.Controls.Add(this.legR1);
            this.Controls.Add(this.armR1);
            this.Controls.Add(this.armL1);
            this.Controls.Add(this.legL1);
            this.Controls.Add(this.body1);
            this.Controls.Add(this.head1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ltr5);
            this.Controls.Add(this.ltr4);
            this.Controls.Add(this.ltr3);
            this.Controls.Add(this.ltr2);
            this.Controls.Add(this.ltr1);
            this.Name = "bubbleSpells";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bubble Spells";
            this.Load += new System.EventHandler(this.bubbleSpells_Load);
            ((System.ComponentModel.ISupportInitialize)(this.legR3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armR3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armL3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.legL3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.body3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.head3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.legR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.legL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.body2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.head2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.legR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.legL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.body1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.head1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox legR3;
        private System.Windows.Forms.PictureBox armR3;
        private System.Windows.Forms.PictureBox armL3;
        private System.Windows.Forms.PictureBox legL3;
        private System.Windows.Forms.PictureBox body3;
        private System.Windows.Forms.PictureBox head3;
        private System.Windows.Forms.PictureBox legR2;
        private System.Windows.Forms.PictureBox armR2;
        private System.Windows.Forms.PictureBox armL2;
        private System.Windows.Forms.PictureBox legL2;
        private System.Windows.Forms.PictureBox body2;
        private System.Windows.Forms.PictureBox head2;
        private System.Windows.Forms.PictureBox legR1;
        private System.Windows.Forms.PictureBox armR1;
        private System.Windows.Forms.PictureBox armL1;
        private System.Windows.Forms.PictureBox legL1;
        private System.Windows.Forms.PictureBox body1;
        private System.Windows.Forms.PictureBox head1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox ltr5;
        private System.Windows.Forms.TextBox ltr4;
        private System.Windows.Forms.TextBox ltr3;
        private System.Windows.Forms.TextBox ltr2;
        private System.Windows.Forms.TextBox ltr1;
        private System.Windows.Forms.Timer timeLtrs;
    }
}